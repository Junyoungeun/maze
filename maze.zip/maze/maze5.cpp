﻿#include <bangtal.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>


const int N = 33;
const int M = 33;
int d[4][2] = { -2, 0, 0, 2, 2, 0, 0, -2 };
int locationN[N], locationN2[N];
int locationM[M], locationM2[M];
int foodxy[2 * N][3];
int obstaclexy[2 * N][2];
int dx = 0, dy = -400 * (N - 1) + 520;
int dir;
int num = 0;
int wallcon[400 * N][400 * M];
int speed = 40;

ObjectID wall[N][M], wall2[N][M], player, player2, start1, start2, food[2 * N], obstacle[2 * N], number, map;
SceneID background, background2;
TimerID movetimer, maptimer;
char numberpng[4][6] = {
	"0.png",
	"1.png",
	"2.png",
	"3.png"
};


int maze[N][M];

void createwallcon();

void mouseCallback(ObjectID object, int x, int y, MouseAction action);

void createwall() {
	for (int i = 0; i < N; i++) {
		for (int j = 0; j < M; j++) {
			if (i % 2 == 1 && j % 2 == 1) continue;
			else maze[i][j] = 1;
		}
	}
}

void createfood();
void createobs();
void touchobs();

void createmaze(int x, int y) {
	maze[x][y] = -1;
	int i = rand() % 4;
	for (int j = 0; j < 4; j++, i++) {
		i %= 4;
		int dx = x + d[i][0];
		int dy = y + d[i][1];
		if (0 < dx && dx < N && 0 < dy && dy < M && maze[dx][dy] == 0) {
			maze[(x + dx) / 2][(y + dy) / 2] = 0;
			createmaze(dx, dy);
		}
	}
}

bool ismoveable();
void eat();
void timerCallback(TimerID timer) {
	if (timer == movetimer) {
		if (dir == 0)dy -= speed;
		else if (dir == 1)dx -= speed;
		else if (dir == 2)dy += speed;
		else dx += speed;
		if (!ismoveable()) {
			if (dir == 0)dy += speed;
			else if (dir == 1)dx += speed;
			else if (dir == 2)dy -= speed;
			else dx -= speed;
			stopTimer(movetimer);
			setTimer(movetimer, 0.06f);
			return;
		}
		touchobs();
		for (int i = 0; i < N; i++) {
			for (int j = 0; j < M; j++) {
				locateObject(wall[i][j], background, locationM[j] + dx, locationN[i] + dy);
			}
		}
		for (int i = 0; i < 2 * N; i++) {
			locateObject(food[i], background, locationM[foodxy[i][1]] + dx + 175, locationN[foodxy[i][0]] + dy + 175);
			locateObject(obstacle[i], background, locationM[obstaclexy[i][1]] + dx + 100, locationN[obstaclexy[i][0]] + dy);
		}

		eat();
		setTimer(movetimer, 0.06f);
		startTimer(movetimer);
	}
	if (timer == maptimer) {
		printf("bye");
		enterScene(background);
		hideObject(map);
	}
}

void keyboard(KeyCode code, KeyState state) {
	if (state == KeyState::KEY_PRESSED) {
		startTimer(movetimer);
		if (code == KeyCode::KEY_UP_ARROW) {
			dir = 0;
		}
		if (code == KeyCode::KEY_RIGHT_ARROW) {
			dir = 1;
		}
		if (code == KeyCode::KEY_DOWN_ARROW) {
			dir = 2;
		}
		if (code == KeyCode::KEY_LEFT_ARROW) {
			dir = 3;
		}
	}
	else if (state == KeyState::KEY_RELEASED) {
		stopTimer(movetimer);
	}
}

int main() {
	srand(time(0));
	setGameOption(GameOption::GAME_OPTION_ROOM_TITLE, false);
	setGameOption(GameOption::GAME_OPTION_INVENTORY_BUTTON, false);
	setGameOption(GameOption::GAME_OPTION_MESSAGE_BOX_BUTTON, false);

	background = createScene("", "background.png");
	background2 = createScene("", "background.png");

	setTimerCallback(timerCallback);
	setKeyboardCallback(keyboard);

	setMouseCallback(mouseCallback);
	touchobs();
	for (int i = 0; i < N; i++) {
		locationN[i] = 400 * (N - i - 1);
		locationN2[i] = 20 * (N - i - 1);
	}
	for (int i = 0; i < M; i++) {
		locationM[i] = 400 * i;
		locationM2[i] = 20 * i;
	}


	createwall();
	createmaze(1, 1);
	for (int i = 0; i < N; i++) {
		for (int j = 0; j < M; j++) {
			if (maze[i][j] == 1) {
				wall[i][j] = createObject("wall.png");
				wall2[i][j] = createObject("wall.png");
			}
			else {
				wall[i][j] = createObject("path.png");
				wall2[i][j] = createObject("path.png");
			}
			setObjectImage(wall[N - 2][M - 2], "end.png");
			setObjectImage(wall2[N - 2][M - 2], "end.png");
			locateObject(wall[i][j], background, locationM[j] + dx, locationN[i] + dy);
			//locateObject(wall2[i][j], background2, locationM[j] + dx, locationN[i] + dy);

			/*scaleObject(wall[i][j], 0.05f);
			locateObject(wall[i][j], background, 20 * (N - i - 1), 20 * j);*/

			scaleObject(wall2[i][j], 0.05f);
			locateObject(wall2[i][j], background2, locationM2[j] + 300, locationN2[i]);
			//locateObject(wall2[i][j], background2, 20 * (N - i - 1)+300, 20 * j);
			//locateObject(wall2[i][j], background2, 20 * (N - i - 1) + 300, 20 * j);
			//540*360


			showObject(wall[i][j]);
			showObject(wall2[i][j]);
		}
	}
	createwallcon();

	movetimer = createTimer(0.06f);
	maptimer = createTimer(5.0f);
	player = createObject("player.png");
	locateObject(player, background, 540, 260);
	showObject(player);

	player2 = createObject("player.png");
	showObject(player2);
	scaleObject(player2, 0.05f);

	/*start1 = createObject("start.png");
	locateObject(start1, background, 500, 230);
	showObject(start1);

	start2 = createObject("start.png");
	locateObject(start2, background2, 500, 230);
	showObject(start2);*/

	number = createObject(numberpng[num]);
	locateObject(number, background, 565, 285);
	showObject(number);

	map = createObject("map.png");
	locateObject(map, background, 1100, 570);


	createfood();
	eat();
	createobs();
	startGame(background);
}


bool ismoveable() {
	int a = 540 - dx;
	int b = 260 - dy;
	for (int i = a; i < a + 200; i++) {
		for (int j = b; j < b + 200; j++) {
			if (wallcon[j][i] == 1) return false;
		}
	}
	if (540 > locationM[M - 2] + dx && 460 < locationN[N - 2] + dy + 400)endGame();
	return true;
}

void createwallcon() {
	for (int i = 0; i < N; i++) {
		for (int j = 0; j < M; j++) {
			if (maze[i][j] == 1) {
				for (int k = locationN[i]; k < locationN[i] + 400; k++) {
					for (int l = locationM[j]; l < locationM[j] + 400; l++) {
						wallcon[k][l] = 1;
					}
				}
			}
		}
	}

}

void mouseCallback(ObjectID object, int x, int y, MouseAction action) {
	//if (object == start1) {
	//	locateObject(player2, background2, locationM2[1] - dx * 0.05 + 305, locationN2[1] - (dy + 400 * (N - 1) + 520) * 0.05 + 55);
	//	enterScene(background2);
	//}
	//if (object == start2) {
	//	enterScene(background);
	//}
	if (object == map) {
		locateObject(player2, background2, locationM2[1] - dx * 0.05 + 305, locationN2[1] - (dy + 400 * (N - 1) + 520) * 0.05 + 55);
		setTimer(maptimer, 5.0f);
		startTimer(maptimer);
		enterScene(background2);
	}

}
//1/4

void createfood() {
	srand(time(NULL));
	int cnt = 0;
	while (cnt < 2 * N) {
		int x = rand() % M;
		int y = rand() % N;
		if (maze[y][x] == 0) {
			food[cnt] = createObject("food.png");
			foodxy[cnt][0] = y;
			foodxy[cnt][1] = x;
			maze[y][x] = -1;
			locateObject(food[cnt], background, locationM[foodxy[cnt][1]] + dx + 175, locationN[foodxy[cnt][0]] + dy + 175);
			showObject(food[cnt]);
			cnt++;
		}
	}
}

void eat() {
	int cnt = 0;
	for (int i = 0; i < 2 * N; i++) {
		if (foodxy[i][2] == 0 && 540 <= locationM[foodxy[i][1]] + dx + 175 && locationM[foodxy[i][1]] + dx + 175 < 690 &&
			260 <= locationN[foodxy[i][0]] + dy + 175 && locationN[foodxy[i][0]] + dy + 175 <= 410) {
			hideObject(food[i]);
			foodxy[i][2] = 1;
			if (num < 3) {
				setObjectImage(number, numberpng[++num]);
			}
			else {
				num -= 3;
				setObjectImage(number, "0.png");
				showObject(map);
			}


		}
	}
	for (int i = 0; i < 2 * N; i++) {
		if (num > 0) {
			setObjectImage(obstacle[i], "obstacle.png");
		}
		else {
			setObjectImage(obstacle[i], "realobstacle.png");
		}

	}
}

void createobs() {
	srand(time(NULL));
	int cnt = 0;
	while (cnt < 2 * N) {
		int x = rand() % M;
		int y = rand() % N;
		if (maze[y][x] == 0) {
			obstacle[cnt] = createObject("realobstacle.png");
			//if (num  1) {
			//	setObjectImage(obstacle[cnt], "obstacle.png");
			//}
			//else { setObjectImage(obstacle[cnt], "realobstacle.png"); }
			obstaclexy[cnt][0] = y;
			obstaclexy[cnt][1] = x;
			maze[y][x] = -1;
			locateObject(obstacle[cnt], background, locationM[obstaclexy[cnt][1]] + dx, locationN[obstaclexy[cnt][0]] + dy);
			showObject(obstacle[cnt]);
			cnt++;
		}
	}
}

void touchobs() {
	int cnt = 0;
	for (int i = 0; i < 2 * N; i++) {
		if (540 <= locationM[obstaclexy[i][1]] + dx + 50 && locationM[obstaclexy[i][1]] + dx + 50 < 740 &&
			260 <= locationN[obstaclexy[i][0]] + dy+50 && locationN[obstaclexy[i][0]] + dy+50 <= 460) {
			dx = 0, dy = -400 * (N - 1) + 520;
		}
	}
}